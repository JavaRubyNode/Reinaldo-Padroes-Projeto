package br.com.delta.principal;

import br.com.delta.generico.BoletoBuilder;
import br.com.delta.modelo.GeradorBoleto;

public class MainBoleto {

	public static void main(String[] args) {
		GeradorBoleto objGerador = new GeradorBoleto();
		
		BoletoBuilder objBoleto = objGerador.gerarBoleto(1);
		objBoleto.imprimirCedente("Peg Pag São José");
		objBoleto.imprimirSacado("Maria Soares Xavier");
		objBoleto.imprimirValor(250.00);
		objBoleto.imprimirCodigoBarras();
		
		objBoleto = objGerador.gerarBoleto(2);
		objBoleto.imprimirCedente("Peg Pag São José II");
		objBoleto.imprimirSacado("Maria Soares Xavier II");
		objBoleto.imprimirValor(350.00);
		objBoleto.imprimirCodigoBarras();
	}

}
