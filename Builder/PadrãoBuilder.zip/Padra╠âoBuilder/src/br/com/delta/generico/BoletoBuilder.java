package br.com.delta.generico;

public interface BoletoBuilder {

	public void imprimirSacado(String sacado);
	public void imprimirCedente(String cedente);
	public void imprimirCodigoBarras();
	public void imprimirValor(double valor);
	
}
