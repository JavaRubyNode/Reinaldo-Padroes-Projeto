package br.com.delta.modelo;

import br.com.delta.generico.BoletoBuilder;

public class ItauBoletoBuilder implements BoletoBuilder {

	@Override
	public void imprimirSacado(String sacado) {
		System.out.println("Imprimir Sacado ITAU "+sacado);
	}
	@Override
	public void imprimirCedente(String cedente) {
		System.out.println("Imprimir Cedente ITAU "+cedente);
	}
	@Override
	public void imprimirCodigoBarras() {
		System.out.println("Imprimir Codigo de Barras ITAU");
	}
	@Override
	public void imprimirValor(double valor) {
		System.out.println("Imprimir Valor ITAU "+valor);
	}

}
