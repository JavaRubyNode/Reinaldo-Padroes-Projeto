package br.com.delta.modelo;

import br.com.delta.generico.BoletoBuilder;

public class BBBoletoBuilder implements BoletoBuilder {

	@Override
	public void imprimirSacado(String sacado) {
		System.out.println("Imprimir Sacado BB "+sacado);
	}
	@Override
	public void imprimirCedente(String cedente) {
		System.out.println("Imprimir Cedente BB "+cedente);
	}
	@Override
	public void imprimirCodigoBarras() {
		System.out.println("Imprimir Codigo de Barras BB");
	}
	@Override
	public void imprimirValor(double valor) {
		System.out.println("Imprimir Valor BB "+valor);
	}

}
