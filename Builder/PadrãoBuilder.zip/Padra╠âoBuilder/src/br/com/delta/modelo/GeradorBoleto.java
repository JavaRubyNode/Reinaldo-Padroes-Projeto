package br.com.delta.modelo;

import br.com.delta.generico.BoletoBuilder;

public class GeradorBoleto {

	public BoletoBuilder gerarBoleto(int tipoBoleto) {
		
		BoletoBuilder objBoleto = null;
		
		switch (tipoBoleto) {
		case 1: // Boleto do Banco do Brasil
			objBoleto = new BBBoletoBuilder();
			break;
		case 2: // Boleto do Banco Itau
			objBoleto = new ItauBoletoBuilder();
			break;			
		default:
			System.out.println("Tipo de Boleto Não Encontrado !!");
			break;
		}
		
		return objBoleto;
	}
	
}
