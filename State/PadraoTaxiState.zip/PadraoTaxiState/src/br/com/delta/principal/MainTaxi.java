package br.com.delta.principal;

import br.com.delta.modelo.Bandeira1;
import br.com.delta.modelo.Bandeira2;
import br.com.delta.modelo.Taximetro;

public class MainTaxi {

	public static void main(String[] args) {
		Taximetro taximetro = new Taximetro(new Bandeira1());
		taximetro.calcularValorCorrida(100);
		taximetro.setBandeira(new Bandeira2());
		taximetro.calcularValorCorrida(100);
	}

}
