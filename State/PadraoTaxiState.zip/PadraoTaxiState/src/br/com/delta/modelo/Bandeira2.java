package br.com.delta.modelo;

import br.com.delta.generico.Bandeira;

public class Bandeira2 implements Bandeira {

	@Override
	public double calculaValorCorrida(double km) {
		return (km * 1.4);
	}

}
