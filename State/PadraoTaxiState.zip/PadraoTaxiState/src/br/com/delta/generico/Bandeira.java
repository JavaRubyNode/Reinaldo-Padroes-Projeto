package br.com.delta.generico;

public interface Bandeira {

	public double calculaValorCorrida(double km);
	
}
