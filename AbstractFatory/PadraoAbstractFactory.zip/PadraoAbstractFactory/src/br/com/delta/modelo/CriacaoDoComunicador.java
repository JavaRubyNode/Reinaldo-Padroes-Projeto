package br.com.delta.modelo;

import br.com.delta.generico.ComunicadorFactory;

public class CriacaoDoComunicador {

public ComunicadorFactory getComunicador(int tipoCartao) {
	
	ComunicadorFactory objComunicador;
	// SE tipoCartao == 1 ENTÃO retorna VisaComunicadorFactory
	if (tipoCartao == 1) {
		objComunicador = new VisaComunicadorFactory(); 
	}
	else { // SE tipoCartao == 2 ou Outro Valor ENTÃO retorna MasterCardComunicadorFactory
		objComunicador = new MasterCardComunicadorFactory();
	}
	
	return objComunicador;
}
	
}
