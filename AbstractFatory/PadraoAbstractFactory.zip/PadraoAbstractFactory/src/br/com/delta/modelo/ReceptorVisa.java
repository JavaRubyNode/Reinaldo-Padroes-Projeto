package br.com.delta.modelo;

import br.com.delta.generico.Receptor;

public class ReceptorVisa implements Receptor {

	@Override
	public void realizarRecepcao() {
		System.out.println("Receptor Visa");
	}

}
