package br.com.delta.modelo;

import br.com.delta.generico.Receptor;

public class ReceptorMasterCard implements Receptor {

	@Override
	public void realizarRecepcao() {
		System.out.println("Receptor MasterCard");

	}

}
