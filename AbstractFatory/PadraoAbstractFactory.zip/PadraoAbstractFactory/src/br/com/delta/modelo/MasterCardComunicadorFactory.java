package br.com.delta.modelo;

import br.com.delta.generico.ComunicadorFactory;
import br.com.delta.generico.Emissor;
import br.com.delta.generico.Receptor;

public class MasterCardComunicadorFactory implements ComunicadorFactory {

	@Override
	public Emissor createEmissor() {
		return new EmissorMasterCard();
	}

	@Override
	public Receptor createReceptor() {
		return new ReceptorMasterCard();
	}

}
