package br.com.delta.modelo;

import br.com.delta.generico.Emissor;

public class EmissorVisa implements Emissor {

	@Override
	public void realizarEmissao() {
		System.out.println("Emissor Visa");		
	}

}
