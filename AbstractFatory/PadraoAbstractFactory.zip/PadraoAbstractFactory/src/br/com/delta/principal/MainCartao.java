package br.com.delta.principal;

import br.com.delta.generico.ComunicadorFactory;
import br.com.delta.modelo.CriacaoDoComunicador;

public class MainCartao {

	public static void main(String[] args) {
		CriacaoDoComunicador objFabrica = new CriacaoDoComunicador();
		ComunicadorFactory objComunicadorFabrica;
		
		objComunicadorFabrica = objFabrica.getComunicador(1);
		objComunicadorFabrica.createEmissor().realizarEmissao();
		objComunicadorFabrica.createReceptor().realizarRecepcao();

		objComunicadorFabrica = objFabrica.getComunicador(2);
		objComunicadorFabrica.createEmissor().realizarEmissao();
		objComunicadorFabrica.createReceptor().realizarRecepcao();
		
	}

}
