package br.com.delta.generico;

public interface Receptor {
	
	public void realizarRecepcao();
	
}
