package br.com.delta.generico;

public interface Emissor {
	
	public void realizarEmissao();

}
