package br.com.delta.generico;

public interface ComunicadorFactory {

	public Emissor createEmissor();
	
	public Receptor createReceptor();
	
}
