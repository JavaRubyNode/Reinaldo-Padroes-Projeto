package br.com.delta.modelo;

public class NegocioPedido {

	public void finalizarPedido() {
		int totalPedido = 0;
		Cliente cliente = new Cliente(10, "Reinaldo", "111.111.111-11", 50);
		Pedido pedido = new Pedido(5, cliente);
		pedido.incluirProduto(new Produto(1, "Leite", 2), 10);
		pedido.incluirProduto(new Produto(2, "Arroz", 10), 5);
		for (PedidoItens itensPedido : pedido.getLista()) {
			totalPedido += itensPedido.getQuantidade() * itensPedido.getProduto().getPreco();
		}
		SPC spc = new SPC();
		// Validar CPF no SPC
		if (spc.validarPessoa(cliente.getCpf())) {
			// Validar Limite de Crédito
			if (cliente.validarLimiteCredito(totalPedido)) {
				pedido.imprimirPedido();
			}
			else {
				System.out.println("Limite de Crédito INVALIDO !!");
			}
		}
		else {
			System.out.println("Cliente Esta NEGATIVADO !!");
		}
	}
	
}
