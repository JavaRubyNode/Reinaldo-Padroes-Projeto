package br.com.delta.modelo;

import java.util.ArrayList;
import java.util.List;

public class Pedido {

	private int id;
	private Cliente cliente;
	private List<PedidoItens> lista;
	
	public Pedido(int id, Cliente cliente) {
		super();
		this.id = id;
		this.cliente = cliente;
		this.lista = new ArrayList<PedidoItens>();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public List<PedidoItens> getLista() {
		return lista;
	}

	public void setLista(List<PedidoItens> lista) {
		this.lista = lista;
	}
	
	public void incluirProduto(Produto prod, int qtde) {
		int idLista = getLista().size() + 1;
		getLista().add(new PedidoItens(idLista, qtde, prod));
	}
	
	public void imprimirPedido() {
		int totalPedido = 0;
		for (PedidoItens itensPedido : getLista()) {
			System.out.println("Produto    " + itensPedido.getProduto().getDescricao());
			System.out.println("Quantidade " + itensPedido.getQuantidade());
			System.out.println("Preço      " + itensPedido.getProduto().getPreco());
			totalPedido += itensPedido.getQuantidade() * itensPedido.getProduto().getPreco();
		}		
		System.out.println("Total do Pedido " + totalPedido);
	}
	
	
}
