package br.com.delta.modelo;

public class Cliente {

	private int id;
	private String nome;
	private String cpf;
	private double limiteCredito;
	
	public Cliente(int id, String nome, String cpf, double limiteCredito) {
		super();
		this.id = id;
		this.nome = nome;
		this.cpf = cpf;
		this.limiteCredito = limiteCredito;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public double getLimiteCredito() {
		return limiteCredito;
	}
	public void setLimiteCredito(double limiteCredito) {
		this.limiteCredito = limiteCredito;
	}
	public boolean validarLimiteCredito(double valorTotalPedido) {
		if (getLimiteCredito() >= valorTotalPedido)
			return true; // limite APROVADO
		else
			return false;  // limite REPROVADO
	}
}
