package br.com.delta.modelo;

public class SPC {

	public boolean validarPessoa(String cpf) {
		return true;
	}
	
}
