package br.com.delta.principal;

import br.com.delta.modelo.NegocioPedido;

public class MainPedido {
	public static void main(String[] args) {
		NegocioPedido negocio = new NegocioPedido();
		negocio.finalizarPedido();
	}
}
