package br.com.delta.modelo;

public class NotaFiscal {

	public void gerarNFEntrada() {
		System.out.println("Gerar NF de Entrada");
	}
	
	public void gerarNFSaida() {
		System.out.println("Gerar NF de Saída");
	}
	
}
