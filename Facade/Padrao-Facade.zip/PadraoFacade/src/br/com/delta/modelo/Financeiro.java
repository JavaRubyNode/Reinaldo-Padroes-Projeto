package br.com.delta.modelo;

public class Financeiro {

	public void gerarContasAPagar() {
		System.out.println("Gerando Contas a Pagar");
	}

	public void gerarContasAReceber() {
		System.out.println("Gerando Contas a Receber");
	}
	
}
