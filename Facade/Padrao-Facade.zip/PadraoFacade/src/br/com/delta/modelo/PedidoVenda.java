package br.com.delta.modelo;

import br.com.delta.generico.Pedido;

public class PedidoVenda implements Pedido {

	@Override
	public void gerarPedido() {
		Estoque est = new Estoque();
		est.gerarEstoqueSaida();
		Financeiro fin = new Financeiro();
		fin.gerarContasAReceber();
		NotaFiscal nf = new NotaFiscal();
		nf.gerarNFSaida();
	}

}
