package br.com.delta.modelo;

public class Estoque {

	public void gerarEstoqueEntrada() {
		System.out.println("Gerando Estoque de Entrada");
	}
	
	public void gerarEstoqueSaida() {
		System.out.println("Gerando Estoque de Saída");
	}
	
}
