package br.com.delta.principal;

import br.com.delta.generico.Pedido;
import br.com.delta.modelo.PedidoVenda;

public class MainPedido {

	public static void main(String[] args) {
		Pedido ped = new PedidoVenda();
		ped.gerarPedido();
	}

}
