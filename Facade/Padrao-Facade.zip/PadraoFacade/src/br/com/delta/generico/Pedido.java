package br.com.delta.generico;

public interface Pedido {

	public void gerarPedido();
	
}
