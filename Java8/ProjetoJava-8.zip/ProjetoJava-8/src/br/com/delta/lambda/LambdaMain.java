package br.com.delta.lambda;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

import br.com.delta.modelo.Produto;

public class LambdaMain {

	public static void main(String[] args) {
		Produto produto1 = new Produto(1, "Caneta");
		Produto produto2 = new Produto(2, "Borracha");
		Produto produto3 = new Produto(3, "Apontador");
		
		List<Produto> listaProdutos = new ArrayList<Produto>();
		listaProdutos.add(produto1);
		listaProdutos.add(produto2);
		listaProdutos.add(produto3);
		// Listagem com FOR()
		for (Produto produto : listaProdutos) {
			System.out.println(produto.getId()+" "+produto.getDescricao());
		}
		
		Consumer<Produto> modeloImp = new Consumer<Produto>() {
			@Override
			public void accept(Produto p) {
				System.out.println(p.getId()+" "+p.getDescricao());
			}			
		};
		// Listagem com Interface Consumer
		listaProdutos.forEach(modeloImp);
		
		// Listagem com Interface Consumer + Lambda
		listaProdutos.forEach(p -> System.out.println(p.getId()+" "+p.getDescricao()));
		 
		listaProdutos.forEach(  ( (Consumer<Produto>) p -> System.out.println("Antes")).
								andThen(p -> System.out.println(p.getId()+" "+p.getDescricao()))); 
// Aplicando LAMBDA na Ordenação 		
//Comparator<Produto> ordenacao = new Comparator<Produto>() {
//	@Override
//	public int compare(Produto o1, Produto o2) {
//		// TODO Auto-generated method stub
//		return (o1.getDescricao().compareTo(o2.getDescricao()));
//	}
//};
listaProdutos.forEach(p -> System.out.println(p.getId()+" "+p.getDescricao()));
//Collections.sort(listaProdutos, ordenacao);
Collections.sort(listaProdutos, (o1,o2) -> o1.getDescricao().compareTo(o2.getDescricao()) );
listaProdutos.forEach(p -> System.out.println(p.getId()+" "+p.getDescricao()));

		
		
		
		
		

	}

}
