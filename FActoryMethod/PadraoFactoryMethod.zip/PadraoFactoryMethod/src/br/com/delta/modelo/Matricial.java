package br.com.delta.modelo;

import br.com.delta.generico.Impressora;

public class Matricial implements Impressora {

	@Override
	public void imprimir(String texto) {
System.out.println("Imprimindo"+texto+" Matricial");

	}

}
