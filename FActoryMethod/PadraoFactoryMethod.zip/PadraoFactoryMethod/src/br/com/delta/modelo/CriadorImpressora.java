package br.com.delta.modelo;

import br.com.delta.generico.Impressora;

public class CriadorImpressora {

	public Impressora criarImpressora(int tipo) {
		Impressora objImp;
		if (tipo == 1) 
			objImp = new JatoTinta();
		else
			objImp = new Matricial();
		return objImp;	
	}
	
}
