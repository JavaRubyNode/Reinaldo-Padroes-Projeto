package br.com.delta.principal;

import br.com.delta.generico.Impressora;
import br.com.delta.modelo.CriadorImpressora;

public class ClienteImpressao {

	public static void main(String[] args) {
CriadorImpressora objCriador = new CriadorImpressora();
Impressora objImp = objCriador.criarImpressora(1);
objImp.imprimir("Reinaldo Jr");
objImp = objCriador.criarImpressora(2);
objImp.imprimir("Reinaldo Jr");
	}

}
