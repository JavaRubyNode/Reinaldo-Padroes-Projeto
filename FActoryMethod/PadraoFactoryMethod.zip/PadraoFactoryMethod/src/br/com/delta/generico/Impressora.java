package br.com.delta.generico;

public interface Impressora {

	public void imprimir(String texto);
	
}
