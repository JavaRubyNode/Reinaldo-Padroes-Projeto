package br.com.delta.modelo;

import br.com.delta.generico.Frete;

public class FreteSP implements Frete {

	@Override
	public double calcularFrete(double preco) {
		return (preco * 0.4);
	}

}
