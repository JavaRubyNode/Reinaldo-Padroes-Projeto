package br.com.delta.modelo;

import java.util.ArrayList;
import java.util.List;

import br.com.delta.generico.Frete;

public class Transporte {

	private int id;
	private Frete frete;
	private Cliente cliente;
	List<TransporteItens> lista;
	
	public Transporte(int id, Cliente cliente) {	
		this.id = id;
		this.cliente = cliente;
		this.lista = new ArrayList<TransporteItens>();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Frete getFrete() {
		return frete;
	}

	public void setFrete(Frete frete) {
		this.frete = frete;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public List<TransporteItens> getLista() {
		return lista;
	}

	public void setLista(List<TransporteItens> lista) {
		this.lista = lista;
	}
	
	public void incluirNaLista(TransporteItens item) {
		getLista().add(item);
	}
	
	public void removerDaLista(TransporteItens item) {
		getLista().remove(item);
	}
	
	public double calcularFreteTotal() {
		double valorFreteTotal = 0;		
		switch (getCliente().getUf()) {
		case "GO":
			setFrete(new FreteGO());
			break;
		case "SP":
			setFrete(new FreteSP());
			break;			
		}		
		for (TransporteItens item : getLista()) {
			valorFreteTotal += getFrete().calcularFrete(item.getQtde() * 
					                                    item.getProduto().getPreco());
		}		
		return valorFreteTotal;
	}
	
	
	
	
}
