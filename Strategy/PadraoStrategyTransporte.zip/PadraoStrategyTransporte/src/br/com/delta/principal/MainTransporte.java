package br.com.delta.principal;

import br.com.delta.modelo.Cliente;
import br.com.delta.modelo.Produto;
import br.com.delta.modelo.Transporte;
import br.com.delta.modelo.TransporteItens;

public class MainTransporte {

	public static void main(String[] args) {
		
	Cliente cliente = new Cliente(1, "Maria", "GO");
	Transporte transporte = new Transporte(1, cliente);
	transporte.incluirNaLista(new TransporteItens(10, new Produto(1, "Arroz", 10)));
	transporte.incluirNaLista(new TransporteItens(10, new Produto(2, "Feijão", 5)));
	System.out.println("Valor do Frete (GO) => " + transporte.calcularFreteTotal());
	transporte.setCliente(new Cliente(2, "Pedro", "SP"));
	System.out.println("Valor do Frete (SP) => " + transporte.calcularFreteTotal());
	
	}

}
