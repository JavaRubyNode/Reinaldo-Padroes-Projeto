package br.com.delta.generico;

public interface Frete {

	public double calcularFrete(double preco);
	
}
