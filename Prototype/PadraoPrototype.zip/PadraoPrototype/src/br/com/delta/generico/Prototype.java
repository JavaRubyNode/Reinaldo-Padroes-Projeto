package br.com.delta.generico;

public interface Prototype<T> {

	public T clonarObjeto();
	
}
