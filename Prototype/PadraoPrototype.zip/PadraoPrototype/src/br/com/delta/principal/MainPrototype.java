package br.com.delta.principal;

import br.com.delta.modelo.Carro;

public class MainPrototype {

	public static void main(String[] args) {
		
Carro objCarro1 = new Carro("Palio","Fiat", "123456789");
System.out.println(objCarro1);
Carro objCarro2 = objCarro1.clonarObjeto();
System.out.println(objCarro2);
	}

}
