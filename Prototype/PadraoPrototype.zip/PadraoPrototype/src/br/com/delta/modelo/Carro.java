package br.com.delta.modelo;

import br.com.delta.generico.Prototype;

public class Carro implements Prototype<Carro> {
	private String nome;
	private String fabricante;
	private String chassi;
	
	public Carro(String nome, String fabricante, String chassi) {
		super();
		this.nome = nome;
		this.fabricante = fabricante;
		this.chassi = chassi;
	}
	
	@Override
	public Carro clonarObjeto() {		
		return new Carro(this.nome,this.fabricante,this.chassi);
	}
	
	public String toString() {
		return (this.nome+" "+this.fabricante+" "+this.chassi); 
	}

}
