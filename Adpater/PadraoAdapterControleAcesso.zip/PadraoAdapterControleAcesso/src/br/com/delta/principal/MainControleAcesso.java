package br.com.delta.principal;

import br.com.delta.modelo.Colaborador;
import br.com.delta.modelo.ControleDePonto;
import br.com.delta.modelo.ControleDePontoAdapter;
import br.com.delta.negocio.NegocioControleDePonto;

public class MainControleAcesso {

	public static void main(String[] args) {
//		Colaborador col = new Colaborador(1234, "Reinaldo Jr");
//		// Controle de Ponto Legado (ControleDePonto)
//		ControleDePonto controlePonto = new ControleDePonto();
//		controlePonto.registraEntrada(col);
//		controlePonto.registraSaida(col);
//		//Controle de Ponto Novo (ControleDePontoAdapter)
//		controlePonto = new ControleDePontoAdapter();
//		controlePonto.registraEntrada(col);
//		controlePonto.registraSaida(col);
		Colaborador col = new Colaborador(1234, "Reinaldo Jr");
		NegocioControleDePonto negocioCP = new NegocioControleDePonto(col, 
				       												new ControleDePonto());
		negocioCP.registraEntrada();
		negocioCP.registraSaida();
		negocioCP.setControleDePonto(new ControleDePontoAdapter());
		negocioCP.registraEntrada();
		negocioCP.registraSaida();		
		
		
		
	}

}
