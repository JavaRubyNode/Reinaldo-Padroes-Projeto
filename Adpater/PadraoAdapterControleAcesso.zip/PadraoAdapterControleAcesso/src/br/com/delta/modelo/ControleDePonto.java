package br.com.delta.modelo;

public class ControleDePonto {

	public void registraEntrada(Colaborador col) {
		System.out.println("Entrada: " + col);
	}
	public void registraSaida(Colaborador col) {
		System.out.println("Saída: " + col);
	}	
}
