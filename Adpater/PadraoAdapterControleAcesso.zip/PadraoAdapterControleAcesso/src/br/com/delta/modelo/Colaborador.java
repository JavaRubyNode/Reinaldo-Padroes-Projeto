package br.com.delta.modelo;

public class Colaborador {

	private int matricula;
	private String nome;
	
	public Colaborador(int matricula, String nome) {
		super();
		this.matricula = matricula;
		this.nome = nome;
	}
	public int getMatricula() {
		return matricula;
	}
	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String toString() {
		return (getNome() + " " + getMatricula());
	}
	
	
}
