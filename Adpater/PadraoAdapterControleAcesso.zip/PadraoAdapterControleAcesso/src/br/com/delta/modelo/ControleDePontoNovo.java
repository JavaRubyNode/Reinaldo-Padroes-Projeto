package br.com.delta.modelo;

public class ControleDePontoNovo {

	public void registraAcesso(Colaborador col, boolean entrada) {
		if (entrada) 
			System.out.println("Entrada: " + col);
		else 
			System.out.println("Saída: " + col);
	}
	
}
