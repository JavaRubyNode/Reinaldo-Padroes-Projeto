package br.com.delta.modelo;

public class ControleDePontoAdapter extends ControleDePonto {

	private ControleDePontoNovo pontoNovo;
	
	public void registraEntrada(Colaborador col) {
		pontoNovo = new ControleDePontoNovo();
		pontoNovo.registraAcesso(col, true);
	}
	
	public void registraSaida(Colaborador col) {
		pontoNovo = new ControleDePontoNovo();
		pontoNovo.registraAcesso(col, false);
	}	
	
}
