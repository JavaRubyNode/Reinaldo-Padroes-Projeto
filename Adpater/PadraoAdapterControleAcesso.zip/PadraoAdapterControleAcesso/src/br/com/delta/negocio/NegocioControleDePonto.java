package br.com.delta.negocio;

import br.com.delta.modelo.Colaborador;
import br.com.delta.modelo.ControleDePonto;

public class NegocioControleDePonto {

	private Colaborador col;
	private ControleDePonto controleDePonto;
	
	public NegocioControleDePonto(Colaborador col,
			ControleDePonto controleDePonto) {
		super();
		this.col = col;
		this.controleDePonto = controleDePonto;
	}
	
	public Colaborador getCol() {
		return col;
	}

	public void setCol(Colaborador col) {
		this.col = col;
	}

	public ControleDePonto getControleDePonto() {
		return controleDePonto;
	}

	public void setControleDePonto(ControleDePonto controleDePonto) {
		this.controleDePonto = controleDePonto;
	}

	public void registraEntrada() {
		getControleDePonto().registraEntrada(getCol());		
	}
	public void registraSaida() {
		getControleDePonto().registraSaida(getCol());
	}	
	
	
}
